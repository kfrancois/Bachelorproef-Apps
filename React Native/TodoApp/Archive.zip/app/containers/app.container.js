import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { View, StyleSheet } from 'react-native';
import { connect } from 'react-redux';

import { actionCreators } from '../reducers/todoReducer';
import Title from '../components/Title';
import Input from '../components/Input';
import List from '../components/List';
import Footer from '../components/Footer';

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'whitesmoke'
  },
  divider: {
    height: 1,
    backgroundColor: 'whitesmoke'
  }
});

const mapStateToProps = state => ({
  items: state.items,
  showCompleted: state.showCompleted
});

class App extends Component {
  static propTypes = {
    items: PropTypes.array.isRequired,
    dispatch: PropTypes.func.isRequired,
    showCompleted: PropTypes.bool.isRequired
  };

  addItem = item => {
    const { dispatch } = this.props;
    dispatch(actionCreators.addItem(item));
  };

  removeItem = index => {
    const { dispatch } = this.props;
    dispatch(actionCreators.removeItem(index));
  };

  toggleItemCompleted = index => {
    const { dispatch } = this.props;
    dispatch(actionCreators.toggleItemCompleted(index));
  };

  toggleShowCompleted = () => {
    const { dispatch } = this.props;
    dispatch(actionCreators.toggleShowCompleted());
  };

  render() {
    const { items, showCompleted } = this.props;

    return (
      <View style={styles.container}>
        <Title> Todo List </Title>
        <Input placeholder={'Enter an item!'} onSubmit={this.addItem} />
        <View style={styles.divider} />
        <List
          items={items}
          onRemoveItem={this.removeItem}
          onToggleItemCompleted={this.toggleItemCompleted}
          showCompleted={showCompleted}
        />
        <View style={styles.divider} />
        <Footer
          onToggleShowCompleted={this.toggleShowCompleted}
          showCompleted={showCompleted}
        />
      </View>
    );
  }
}

export default connect(mapStateToProps)(App);
